<?php

return [
    
    'success' => [
        'LOGIN_SUCCESS' => 'Internal Server Error',
    ]
    ,
    'error' => [
        'INTERNAL_SERVER_ERROR' => 'Internal Server Error',
	    'ONLY_ADMIN' => 'Only Admin can Access',
	    'USER_NOT_EXIST' => 'User does not Exist',
	    'INVALID_PASSWORD' => 'Invalid Password',
    ],
    'config' => [
        'URL' => 'http://www.sulthanallaudeen.com',
    ]

];