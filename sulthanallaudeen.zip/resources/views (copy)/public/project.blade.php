@extends('layout.public')
@section('content')

   <div class="container theme-showcase" role="main">

   <div class="container">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Projects
                    <small> Under Construction</small>
                </h1>
            </div>
        </div>
        <!-- /.row -->

        <!-- Project One -->
        
        <!-- /.row -->

        <hr>

        <hr>

        
        
        <!-- /.row -->


    </div>
   


      
    </div>

    @stop